// a4_sort_implementations.h

/////////////////////////////////////////////////////////////////////////
//
// Student Info
// ------------
//
// Name : <Miloni Hareshbhai Khunt>
// St.# : <301570476>
// Email: <mhk21@sfu.ca>
//
//
// Statement of Originality
// ------------------------
//
// All the code and comments below are my own original work. For any non-
// original work, I have provided citations in the comments with enough
// detail so that someone can see the exact source and extent of the
// borrowed work.
//
// In addition, I have not shared this work with anyone else, and I have
// not seen solutions from other students, tutors, websites, books,
// etc.
//
/////////////////////////////////////////////////////////////////////////

#pragma once

#include "a4_base.h"

using namespace std;

ulong num_comps = 0;
//
// Put the implementations of all the functions listed in a4_base.h here.
//

// filling vectors with random values
vector<int> rand_vec(int n, int min, int max)
{
    srand(time(0));
    vector <int> v;
    for(int i=0; i < n; i++)
    {
        v.push_back(rand()%(max - min + 1)  + min);
    }
    return v;
}
// is sorted function
template <typename T>
bool is_sorted(vector<T> &v)
{
    for (int i = 1; i < v.size(); i++)
    {
        if (v[i-1] > v[i])
        {
            return false;
        }
    }
    return true;
}

// swap helping function 
template <typename T>
void swap(T &a, T &b)
{
    T temp = a;
    a = b;
    b = temp;
}

//------------------------------------BUBBLE SORT--------------------------------------------------------------------------------------------------------------
// implementing with the help of Problem_Solving_with_C++_(9th_Savitch) textbook (CMPT130)
template <typename T>
SortStats bubble_sort(vector<T> &v)
{
    SortStats s;
    s.sort_name="Bubble Sort";
    s.vector_size = v.size();
    clock_t start = clock();

    // if vector size is less than 1 or 0 then it is sorted and time is 0
    if (v.size() <= 1) 
    {
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    // starting loop from 0 and going till last-1 anf fixing the greatest at last and traversing through array
    for (int i = 0; i < v.size(); i++)
    {
        for (int j = 0; j < v.size() - 1; j++)
        {
            // counting number of comparisons
            num_comps++;
            // swapping if the element is greater than the next element
            if (v[j] > v[j + 1])
            {
                std::swap(v[j], v[j + 1]);
            }
        }
    }
    // storing number of comparisons and time
    s.num_comparisons = num_comps;
    clock_t end = clock();
    s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
    return s;
}

//------------------------------------INSERTION SORT------------------------------------------------------------------------------------------------

//implementing with the help of CMPT130 notes provided by Prof. Yonas Weldeselassie 
template <typename T>
SortStats insertion_sort(vector<T> &v)
{
    SortStats s;
    s.sort_name = " Insertion Sort";
    s.vector_size = v.size();
    clock_t start = clock();
    // if vector size is less than 1 or 0 then it is sorted and time is 0
    if (v.size() <= 1) 
    {
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    // we start the first loop with index 1 as while comapring we will compare 
    //one element previous the current element thus the second loop will start from i-1
    for(int i = 1; i < v.size(); i++)
    {
        //assigning temp to the current element
        T temp = v[i];
        int j = i-1;
        // comparing the current element with the previous element and swapping if the previous element is greater
        while(j >= 0 && v[j] > temp)
        {
            s.num_comparisons++;
            v[j+1] = v[j];
            j--;
        }
        // storing the current element in the correct position
        v[j+1] = temp;
    }
    //s.num_comparisons = insertion_comps;
    clock_t end = clock();
    s.cpu_running_time_sec = (double)(end - start)/CLOCKS_PER_SEC;
    return s;

}

//------------------------------------------SELECTION SORT-----------------------------------------------------------------------------------

// implementing with the help of Problem_Solving_with_C++_(9th_Savitch) textbook (CMPT130)
template <typename T>
SortStats selection_sort(vector<T> &v)
{
    SortStats s;
    s.sort_name = "Selection Sort";
    s.vector_size = v.size();
    clock_t start = clock();
    int min_index ;
    // we start the first loop with index 0 and second loop with i+1 as while comapring we will compare
    //one element next to  the current element. we will start fixing smallest element in front side and sort the rest
    // if vector size is less than 1 or 0 then it is sorted and time is 0
    if (v.size() <= 1) 
    {
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    for(int i=0; i< v.size()-1; i++)
    {
        // assigning the first element as the smallest element
        min_index = i;
        // comparing the smallest element with the rest of the elements 
        //and swapping if the element is smaller and fixing the element at the front
        for(int j= i + 1; j < v.size(); j++)
        {
            s.num_comparisons++;
            if(v[j] < v[min_index])
            {
                min_index = j;
            }
        }
        // swapping the smallest element with the current element
        if(min_index != i)
        {
             std::swap(v[min_index] , v[i]);
        }
    }
    clock_t end = clock();
    s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
    return s;
}

//--------------------------------------------------MERGE SORT--------------------------------------------------------------------------

// implementing with the help of textbook (CMPT225)
// helping function for merge sort
int merge_comparison = 0;
template <typename E, typename C>
void merge(vector<E>& in, vector<E>& out, const C& less, int b, int m) 
{
    int i = b; // index into run #1
    int j = b + m; // index into run #2
    int n = in.size();
    int e1 = std::min(b + m, n); // end of run #1
    int e2 = std::min(b + 2*m, n); // end of run #2
    int k = b;

    while ((i < e1) && (j < e2))    
    {
        // incrementing the number of comparisons
        merge_comparison++;
        if(!less(in[j], in[i])) // append smaller to S
        {    
            out[k++] = in[i++];
        }
        else
        {
            out[k++] = in[j++];
        }
    }
    while (i < e1) // copy rest of run 1 to S
    {
        out[k++] = in[i++];
    }
    while (j < e2) // copy rest of run 2 to S
    {
        out[k++] = in[j++];
    }
}

template<typename E>
SortStats merge_sort(vector<E> &v)
{
    typedef vector<E> vect;
    SortStats s;
    s.sort_name = "Merge Sort";
    s.vector_size = v.size();
    clock_t start = clock();
    less<E> less;

    vect v1(v); vect* in = &v1; // initial input vector
    vect v2(v.size()); vect* out = &v2; // initial output vector
    //if vector size is less than 1 or 0 then it is sorted and time is 0
    if(v.size() <= 1)
    { 
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    for (int m = 1; m < v.size(); m *= 2) 
    { // list sizes doubling
        for (int b = 0; b < v.size(); b += 2*m) 
        { // beginning of list
            merge(*in, *out, less,  b, m); // merge sublists
        }
        std::swap(in, out); // swap input with output
    }
    // copying the sorted vector to the original vector
    v = *in; 
    s.num_comparisons = merge_comparison;
    clock_t end = clock();
    s.cpu_running_time_sec = (double)(end - start)/CLOCKS_PER_SEC;

    return s;
}


//-------------------------------------------------QUICK SORT--------------------------------------------------------------------------

template<typename T>
int partition(vector<T> &v, int start, int end, ulong & quick_comps)
{
   // taking the last element as pivot
    T pivot = v[end];
    int pivotindex = start;
    // comparing the pivot with rest of the elements and swapping if the element is smaller
    for (int j = start; j < end; j++)
    {
        // incrementing the number of comparisons
        quick_comps++;
        // if the element is smaller than pivot then swap the element with the element at pivot index
        if(v[j] <= pivot){
            std::swap(v[pivotindex],v[j]);
            ++pivotindex;
        }
    }
    // swapping the pivot with the element at pivot index
    std::swap(v[pivotindex],v[end]);
    return pivotindex;
}

template <typename T>
void quick_sort_helper(vector<T> &v, int start, int end, ulong& quick_comps)
{
    // if start is greater than end then return
    while(start >= end)
    {
        return;
    }
    // partitioning the vector
    int pivot = partition(v, start, end, quick_comps);
    // recursively calling the quick sort function
    quick_sort_helper(v, start, pivot-1,quick_comps);
    quick_sort_helper(v, pivot+1, end, quick_comps);
}

template <typename T>
SortStats quick_sort(vector<T> &v)
{
    SortStats s;
    s.sort_name = "quick Sort";
    s.vector_size = v.size();
    clock_t start = clock(); 
    //if vector size is less than 1 or 0 then it is sorted and time is 0
    if(v.size() <= 1)
    {
        
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    // calling the helper function
    ulong quick_comps=0;
    quick_sort_helper(v,0,v.size()-1, quick_comps);
    //asssigning the number of comparisons and time
    s.num_comparisons = quick_comps;
    clock_t end = clock();
    s.cpu_running_time_sec = double(end - start) / CLOCKS_PER_SEC;

    return s;
} 

//------------------------------------------SHELL SORT----------------------------------------------------------------------------------
//implemented with help of youtube video
// link: https://youtu.be/SHcPqUe2GZM
template <typename T>
SortStats shell_sort(vector<T> &v)
{
    SortStats s;
    s.sort_name = "Shell Sort";
    s.vector_size = v.size();
    clock_t start = clock();
    //if vector size is less than 1 or 0 then it is sorted and time is 0
    if(v.size() <= 1)
    {   
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    // taking the gap as half of the vector size
    for(int gap = v.size()/2 ; gap >=1; gap /= 2)
    {
        // comparing the elements at gap distance and swapping if the element at gap distance is smaller
        for(int j = gap; j < v.size(); j++)
        {
            // incrementing the number of comparisons
            for(int i = j-gap; i >= 0; i -= gap)
            {
                // incrementing the number of comparisons
                s.num_comparisons++;
                // if the element at gap distance is smaller than the element at i then swap the elements
                if(v[i+gap] > v[i])
                    break;
                else
                    std::swap(v[i+gap] ,  v[i]);
            }
        }
    }
    
    clock_t end = clock();
    s.cpu_running_time_sec = (double)(end - start)/CLOCKS_PER_SEC;
    return s;
}

//-------------------------------------------------------IQUICK SORT---------------------------------------------------------------------------

template <typename T>
void iquick_sort(vector <T> &v, int start, int end, ulong &iquick_comps)
{
    //if start index is greater than end index, return
    iquick_comps++;
    if(start >= end)
    {
        return;
    }
    //if size of vector is less than 5, use insertion sort 5 is threshold value
    if(v.size() <= 5)
    {
        //calling the insertion sort function
        insertion_sort(v);
    }
    else
    {
        //partitioning the vector
        int pivotIndex = partition(v,start,end,iquick_comps);
        //recursively calling the iquick sort function
        iquick_sort(v,start,pivotIndex-1,iquick_comps);
        iquick_sort(v, pivotIndex+1, end, iquick_comps);
    }
}
template<typename T>
SortStats iquick_sort(vector<T> &v)
{
    SortStats s;
    s.sort_name = "iquick sort";
    s.vector_size = v.size();
    clock_t start = clock();

    //if vector size is less than 1 or 0 then it is sorted and time is 0
    if(v.size() <= 1)
    {
        s.num_comparisons = 0;
        clock_t end = clock();
        s.cpu_running_time_sec = (double) (end - start)/CLOCKS_PER_SEC;
        return s;
    }
    //calling the helper function
    iquick_sort(v, 0, v.size()-1,s.num_comparisons);

    clock_t end = clock();

    s.cpu_running_time_sec = (double)(end - start)/ CLOCKS_PER_SEC;
    return s;
}